#########################################
# Assessment S3 Bucket
#########################################

resource "aws_s3_bucket" "assessment" {
  count  = var.create_assessment_s3_bucket ? 1 : 0
  bucket = "${var.name_prefix}-assessment-${random_string.suffix.result}"
  tags   = local.merged_tags
}

resource "aws_s3_bucket_versioning" "assessment" {
  count  = var.create_assessment_s3_bucket ? 1 : 0
  bucket = aws_s3_bucket.assessment[0].id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "assessment" {
  count  = var.create_assessment_s3_bucket ? 1 : 0
  bucket = aws_s3_bucket.assessment[0].id

  rule {
    apply_server_side_encryption_by_default {
      kms_master_key_id = local.kms_arn
      sse_algorithm     = "aws:kms"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "assessment" {
  count                   = var.create_assessment_s3_bucket ? 1 : 0
  bucket                  = aws_s3_bucket.assessment[0].id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_policy" "assessment" {
  count  = var.create_assessment_s3_bucket ? 1 : 0
  bucket = aws_s3_bucket.assessment[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid : "DenyInsecureTransport",
      Effect : "Deny",
      Principal : "*",
      Action : "s3:*",
      Resource = [
        "arn:${data.aws_partition.current.partition}:s3:::${aws_s3_bucket.assessment[0].id}",
        "arn:${data.aws_partition.current.partition}:s3:::${aws_s3_bucket.assessment[0].id}/*"
      ],
      Condition : {
        Bool : { "aws:SecureTransport" : "false" }
      }
    }]
  })
}

#########################################
# Logs S3 Bucket (optional)
#########################################

resource "aws_s3_bucket" "logs" {
  count  = var.create_logs_s3_bucket ? 1 : 0
  bucket = "${var.name_prefix}-logs-${random_string.suffix.result}"
  tags   = local.merged_tags
}

resource "aws_s3_bucket_versioning" "logs" {
  count  = var.create_logs_s3_bucket ? 1 : 0
  bucket = aws_s3_bucket.logs[0].id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "logs" {
  count  = var.create_logs_s3_bucket ? 1 : 0
  bucket = aws_s3_bucket.logs[0].id

  rule {
    apply_server_side_encryption_by_default {
      kms_master_key_id = local.kms_arn
      sse_algorithm     = "aws:kms"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "logs" {
  count                   = var.create_logs_s3_bucket ? 1 : 0
  bucket                  = aws_s3_bucket.logs[0].id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_policy" "logs" {
  count  = var.create_logs_s3_bucket ? 1 : 0
  bucket = aws_s3_bucket.logs[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid : "DenyInsecureTransport",
      Effect : "Deny",
      Principal : "*",
      Action : "s3:*",
      Resource = [
        "arn:${data.aws_partition.current.partition}:s3:::${aws_s3_bucket.logs[0].id}",
        "arn:${data.aws_partition.current.partition}:s3:::${aws_s3_bucket.logs[0].id}/*"
      ],
      Condition : {
        Bool : { "aws:SecureTransport" : "false" }
      }
    }]
  })
}
