#########################################
# DMS IAM Roles
#########################################

# VPC Role: Allows DMS to manage ENIs in your VPC
resource "aws_iam_role" "dms_vpc_role" {
  count              = var.create_dms_roles ? 1 : 0
  name               = local.dms_role_names.vpc
  path               = var.iam_role_path
  assume_role_policy = data.aws_iam_policy_document.dms_assume_role.json
  tags               = var.tags
}

resource "aws_iam_role_policy_attachment" "dms_vpc_role_policy" {
  count      = var.create_dms_roles ? 1 : 0
  role       = aws_iam_role.dms_vpc_role[0].name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonDMSVPCManagementRole"
}

# CloudWatch Logs Role: Allows DMS to publish logs
resource "aws_iam_role" "dms_cloudwatch_logs_role" {
  count              = var.create_dms_roles ? 1 : 0
  name               = local.dms_role_names.cloudwatch
  path               = var.iam_role_path
  assume_role_policy = data.aws_iam_policy_document.dms_assume_role.json
  tags               = var.tags
}

resource "aws_iam_role_policy_attachment" "dms_cloudwatch_logs_role_policy" {
  count      = var.create_dms_roles ? 1 : 0
  role       = aws_iam_role.dms_cloudwatch_logs_role[0].name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonDMSCloudWatchLogsRole"
}

# Access-for-Endpoint Role: Required for S3, Redshift, Kinesis
resource "aws_iam_role" "dms_access_for_endpoint" {
  count              = var.create_dms_roles ? 1 : 0
  name               = local.dms_role_names.access
  path               = var.iam_role_path
  assume_role_policy = data.aws_iam_policy_document.dms_assume_role.json
  tags               = var.tags
}

resource "aws_iam_role_policy_attachment" "dms_access_for_endpoint_policy" {
  count      = var.create_dms_roles ? 1 : 0
  role       = aws_iam_role.dms_access_for_endpoint[0].name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonDMSRedshiftS3Role"
}

#########################################
# Assume Role Policy Document
#########################################
data "aws_iam_policy_document" "dms_assume_role" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["dms.amazonaws.com"]
    }
  }
}
