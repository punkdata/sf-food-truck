#########################################
# Environment / Meta
#########################################

output "account_id" {
  description = "AWS account ID"
  value       = data.aws_caller_identity.current.account_id
}

output "region" {
  description = "AWS region"
  value       = data.aws_region.current.name
}

output "partition" {
  description = "AWS partition"
  value       = data.aws_partition.current.partition
}

#########################################
# KMS
#########################################

output "kms_key_arn" {
  description = "ARN of the KMS CMK used for all DMS resources"
  value       = local.kms_arn
}

#########################################
# Replication Instance
#########################################

output "replication_instance_id" {
  description = "DMS replication instance identifier"
  value       = aws_dms_replication_instance.this.replication_instance_id
}

output "replication_instance_arn" {
  description = "DMS replication instance ARN"
  value       = aws_dms_replication_instance.this.replication_instance_arn
}

#########################################
# Endpoints
#########################################

output "source_endpoints" {
  description = "Map of source endpoint ARNs keyed by endpoint ID"
  value       = { for k, v in aws_dms_endpoint.source : k => v.endpoint_arn }
}

output "target_endpoints" {
  description = "Map of target endpoint ARNs keyed by endpoint ID"
  value       = { for k, v in aws_dms_endpoint.target : k => v.endpoint_arn }
}

#########################################
# Tasks
#########################################

output "replication_task_ids" {
  description = "Map of replication task IDs keyed by task key"
  value       = { for k, v in aws_dms_replication_task.task : k => v.replication_task_id }
}

output "replication_task_arns" {
  description = "Map of replication task ARNs keyed by task key"
  value       = { for k, v in aws_dms_replication_task.task : k => v.replication_task_arn }
}

#########################################
# Premigration Assessments
#########################################

output "premigration_assessment_task_arns" {
  description = "Map of premigration assessment task ARNs keyed by assessment key"
  value       = { for k, v in aws_dms_replication_task.premigration : k => v.replication_task_arn }
}

#########################################
# S3 (internal buckets)
#########################################

output "assessment_s3_bucket_name" {
  description = "S3 bucket for premigration assessment reports (if created)"
  value       = local.assessment_bucket_name
}

output "logs_s3_bucket_name" {
  description = "S3 bucket for task logs (if created)"
  value       = local.logs_bucket_name
}

#########################################
# IAM (if created)
#########################################

output "dms_vpc_role_arn" {
  description = "ARN of the DMS VPC role (if created)"
  value       = try(aws_iam_role.dms_vpc_role[0].arn, null)
}

output "dms_cloudwatch_logs_role_arn" {
  description = "ARN of the DMS CloudWatch Logs role (if created)"
  value       = try(aws_iam_role.dms_cloudwatch_logs_role[0].arn, null)
}
