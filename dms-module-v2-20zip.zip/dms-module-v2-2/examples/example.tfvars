# ------------------------------------------------------------------------------
# Required values
# ------------------------------------------------------------------------------

# Prefix used in all resource names
name_prefix = "example-dms"

# Replication instance size (choose an instance type that matches your workload)
replication_instance_class = "dms.t3.medium"

# Use an existing subnet group (must already be created in your VPC)
replication_subnet_group_name = "my-dms-subnet-group"

# Attach security groups (must exist in the same VPC as the subnet group)
vpc_security_group_ids = [
  "sg-0123456789abcdef0"
]

# ------------------------------------------------------------------------------
# Optional values (commonly set)
# ------------------------------------------------------------------------------

# Tags applied to all resources
tags = {
  Environment = "dev"
  Project     = "migration-demo"
}

# Whether to let module create IAM roles for DMS
create_dms_roles = true

# Custom IAM role path (OPA compliance)
iam_role_path = "/role/dms/"

# Whether to create a new KMS key (set false and provide kms_key_arn to use existing)
create_kms_key = true

# Enable CloudWatch logs
create_cw_logs              = true
cw_log_group_retention_days = 14

# Enable S3 bucket for premigration assessment reports
create_assessment_s3_bucket = true

# Enable S3 bucket for task logs
create_logs_s3_bucket = false
subnet_ids            = ["subnet-12345678", "subnet-abcdef12"]
