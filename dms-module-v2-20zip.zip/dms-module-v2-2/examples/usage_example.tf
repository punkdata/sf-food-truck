provider "aws" {
  region = var.region
}

resource "aws_security_group" "dms_sg" {
  name        = "${var.name_prefix}dms-sg"
  description = "Security group for DMS replication instance"
  vpc_id      = var.vpc_id

  ingress {
    description = "Allow PostgreSQL from anywhere (adjust in production)"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = var.tags
}

data "aws_secretsmanager_secret" "dms_user" {
  name = var.master_secret_name
}

data "aws_secretsmanager_secret_version" "dms_user" {
  secret_id = data.aws_secretsmanager_secret.dms_user.id
}

resource "aws_secretsmanager_secret" "src" {
  name = "${var.name_prefix}${var.src_secret_key}-dms-secret"
  tags = var.tags
}

resource "aws_secretsmanager_secret_version" "src" {
  secret_id     = aws_secretsmanager_secret.src.id
  secret_string = jsonencode(jsondecode(data.aws_secretsmanager_secret_version.dms_user.secret_string)[var.src_secret_key])
}

resource "aws_secretsmanager_secret" "tgt" {
  name = "${var.name_prefix}${var.tgt_secret_key}-dms-secret"
  tags = var.tags
}

resource "aws_secretsmanager_secret_version" "tgt" {
  secret_id     = aws_secretsmanager_secret.tgt.id
  secret_string = jsonencode(jsondecode(data.aws_secretsmanager_secret_version.dms_user.secret_string)[var.tgt_secret_key])
}

resource "aws_kms_key" "dms" {
  description             = "KMS CMK for DMS resources (${var.name_prefix})"
  deletion_window_in_days = 7
  enable_key_rotation     = true
  tags                    = var.tags
}

resource "aws_kms_alias" "dms" {
  name          = "alias/${var.name_prefix}dms"
  target_key_id = aws_kms_key.dms.key_id
}

resource "random_string" "suffix" {
  length  = 6
  special = false
  upper   = false
}

resource "aws_s3_bucket" "dms_assessment" {
  bucket = "${var.name_prefix}dms-assessment-${random_string.suffix.result}"
  tags   = var.tags
}

data "aws_iam_policy_document" "dms_assume" {
  statement {
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["dms.amazonaws.com"]
    }
    actions = ["sts:AssumeRole"]
  }
}

resource "aws_iam_role" "dms_secrets" {
  name               = "${var.name_prefix}dms-secrets-role"
  assume_role_policy = data.aws_iam_policy_document.dms_assume.json
  path               = var.iam_role_path
  tags               = var.tags
}

resource "aws_iam_role_policy" "dms_secrets_access" {
  name = "${var.name_prefix}dms-secrets-access"
  role = aws_iam_role.dms_secrets.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = ["secretsmanager:GetSecretValue"]
        Resource = [
          aws_secretsmanager_secret.src.arn,
          aws_secretsmanager_secret.tgt.arn
        ]
      },
      {
        Effect   = "Allow"
        Action   = ["kms:Decrypt"]
        Resource = aws_kms_key.dms.arn
      }
    ]
  })
}

resource "aws_iam_role" "dms_s3" {
  name               = "${var.name_prefix}dms-s3-role"
  assume_role_policy = data.aws_iam_policy_document.dms_assume.json
  path               = var.iam_role_path
  tags               = var.tags
}

resource "aws_iam_role_policy" "dms_s3_access" {
  name = "${var.name_prefix}dms-s3-access"
  role = aws_iam_role.dms_s3.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = ["s3:PutObject", "s3:GetObject", "s3:ListBucket"]
        Resource = [
          aws_s3_bucket.dms_assessment.arn,
          "${aws_s3_bucket.dms_assessment.arn}/*"
        ]
      },
      {
        Effect   = "Allow"
        Action   = ["kms:Encrypt", "kms:Decrypt", "kms:GenerateDataKey"]
        Resource = aws_kms_key.dms.arn
      }
    ]
  })
}

resource "aws_iam_role" "dms_logs" {
  name               = "${var.name_prefix}dms-logs-role"
  assume_role_policy = data.aws_iam_policy_document.dms_assume.json
  path               = var.iam_role_path
  tags               = var.tags
}

resource "aws_iam_role_policy" "dms_logs_access" {
  name = "${var.name_prefix}dms-logs-access"
  role = aws_iam_role.dms_logs.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
        Resource = "*"
      }
    ]
  })
}

module "dms" {
  source = "../" # path to your dms-module

  name_prefix                = var.name_prefix
  subnet_ids                 = var.subnet_ids
  vpc_security_group_ids     = [aws_security_group.dms_sg.id]
  replication_instance_class = var.replication_instance_class

  create_kms_key              = false
  kms_key_arn                 = aws_kms_key.dms.arn
  create_assessment_s3_bucket = false
  assessment_bucket_name      = aws_s3_bucket.dms_assessment.bucket

  source_endpoints = {
    src1 = {
      engine_name = "postgres"
      secrets_manager = {
        arn      = aws_secretsmanager_secret.src.arn
        role_arn = aws_iam_role.dms_secrets.arn
      }
    }
  }

  target_endpoints = {
    tgt1 = {
      engine_name = "postgres"
      secrets_manager = {
        arn      = aws_secretsmanager_secret.tgt.arn
        role_arn = aws_iam_role.dms_secrets.arn
      }
    }
  }

  replication_tasks = {
    full_load = {
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"
      migration_type     = "full-load"
      table_mappings = {
        rules = [
          {
            "rule-type"      = "selection"
            "rule-id"        = "1"
            "rule-name"      = "1"
            "object-locator" = { "schema-name" = "public", "table-name" = "%" }
            "rule-action"    = "include"
          }
        ]
      }
      replication_task_settings = {
        TargetMetadata   = { SupportLobs = true }
        FullLoadSettings = { TargetTablePrepMode = "DO_NOTHING" }
      }
    }
  }

  assessments = {
    assess1 = {
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"
      table_mappings = {
        rules = [
          {
            "rule-type"      = "selection"
            "rule-id"        = "1"
            "rule-name"      = "1"
            "object-locator" = { "schema-name" = "public", "table-name" = "%" }
            "rule-action"    = "include"
          }
        ]
      }
      assessment_settings = {
        EnableAssessmentRun = true
        RulesToEnable       = ["All"]
      }
    }
  }

  tags = var.tags
}

################
# variables
#################

variable "region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "vpc_id" {
  description = "The VPC ID where the DMS replication instance will live"
  type        = string
}

variable "master_secret_name" {
  description = "Name of the existing master secret (looked up by dms_user)"
  type        = string
}

variable "src_secret_key" {
  description = "Subkey inside master_secret for the source DB"
  type        = string
}

variable "tgt_secret_key" {
  description = "Subkey inside master_secret for the target DB"
  type        = string
}

variable "name_prefix" {
  description = "Prefix for resource names"
  type        = string
}

variable "subnet_ids" {
  type        = list(string)
  description = "List of subnet IDs for the DMS replication subnet group"
}

variable "replication_instance_class" {
  type        = string
  description = "DMS replication instance type (e.g., dms.t3.medium)"
}

variable "iam_role_path" {
  description = "Path for DMS IAM roles (e.g., /role/dms/)"
  type        = string
  default     = "/role/dms/"
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "Tags applied to resources"
}

################
# tfvar file
#################

region = "us-east-1"
vpc_id = "vpc-12345678"

master_secret_name = "master_secret"
src_secret_key     = "src_postgres"
tgt_secret_key     = "tgt_postgres"

name_prefix                = "example-dms-"
subnet_ids                 = ["subnet-12345678", "subnet-abcdef12"]
replication_instance_class = "dms.t3.medium"

tags = {
  Environment = "dev"
  Project     = "dms-sample"
  Owner       = "infra-team"
}
