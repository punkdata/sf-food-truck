# 🔹 Minimal CI/CD safe tfvars
# Ensures terraform plan/apply never hangs waiting for inputs.

replication_instance_class = "dms.t3.medium"

subnet_ids = [
  "subnet-0123456789abcdef0",
  "subnet-abcdef0123456789"
]

vpc_security_group_ids = ["sg-0123456789abcdef0"]

tags = {
  Environment = "dev"
  Owner       = "platform-team"
}

# IAM role path (required by module, default AWS convention is /service-role/)
iam_role_path = "/service-role/"

# Avoid AWS errors when roles already exist
create_dms_roles = false
name_prefix      = "example-dms-"
