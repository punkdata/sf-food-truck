#########################################
# CloudWatch Log Group (optional)
#########################################

resource "aws_cloudwatch_log_group" "dms" {
  count             = var.create_cw_logs ? 1 : 0
  name              = "${var.name_prefix}-dms-logs"
  retention_in_days = var.cw_log_group_retention_days
  kms_key_id        = local.kms_arn
  tags              = local.merged_tags
}
