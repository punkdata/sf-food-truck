#########################################
# Random suffix for uniqueness
#########################################

resource "random_string" "suffix" {
  length  = 6
  upper   = false
  special = false
}

#########################################
# KMS CMK (optional)
#########################################

resource "aws_kms_key" "this" {
  count                   = var.kms_key_arn == null && var.create_kms_key ? 1 : 0
  description             = "DMS CMK for ${var.name_prefix}"
  deletion_window_in_days = 7
  enable_key_rotation     = true
  policy                  = data.aws_iam_policy_document.kms_policy.json
  tags                    = local.merged_tags
}

resource "aws_kms_alias" "this" {
  count         = var.kms_key_arn == null && var.create_kms_key ? 1 : 0
  name          = "alias/${var.name_prefix}-dms-${random_string.suffix.result}"
  target_key_id = aws_kms_key.this[0].id
}

#########################################
# Test-mode KMS policy
#########################################

data "aws_iam_policy_document" "kms_policy" {
  # Root has full access
  statement {
    sid    = "EnableRootAccountFullAccess"
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = [local.account_root_arn]
    }
    actions   = ["kms:*"]
    resources = ["*"]
  }

  # Allow account-wide use (test mode, permissive)
  statement {
    sid    = "AllowAccountWideUse"
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = ["*"]
    }
    actions = [
      "kms:Encrypt",
      "kms:Decrypt",
      "kms:ReEncrypt*",
      "kms:GenerateDataKey*",
      "kms:DescribeKey"
    ]
    resources = ["*"]
  }
}
