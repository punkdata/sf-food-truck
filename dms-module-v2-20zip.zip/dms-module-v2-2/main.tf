#########################################
# DMS Replication Instance
#########################################

resource "aws_dms_replication_instance" "this" {
  replication_instance_id      = "${var.name_prefix}-ri"
  replication_instance_class   = var.replication_instance_class
  allocated_storage            = var.allocated_storage
  apply_immediately            = var.apply_immediately
  publicly_accessible          = var.publicly_accessible
  auto_minor_version_upgrade   = var.auto_minor_version_upgrade
  allow_major_version_upgrade  = var.allow_major_version_upgrade
  preferred_maintenance_window = var.preferred_maintenance_window

  replication_subnet_group_id = local.subnet_group_name
  vpc_security_group_ids      = var.vpc_security_group_ids

  kms_key_arn = local.kms_arn

  tags = local.merged_tags
}

#########################################
# DMS Endpoints - Sources
#########################################

resource "aws_dms_endpoint" "source" {
  for_each = var.source_endpoints

  endpoint_id   = each.key
  endpoint_type = "source"
  engine_name   = each.value.engine_name

  server_name   = try(each.value.server_name, null)
  port          = try(each.value.port, null)
  database_name = try(each.value.database_name, null)
  username      = try(each.value.auth_mode, "secrets_manager") == "basic" ? try(each.value.username, null) : null
  password      = try(each.value.auth_mode, "secrets_manager") == "basic" ? try(each.value.password, null) : null

  secrets_manager_arn             = try(each.value.auth_mode, "secrets_manager") == "secrets_manager" ? try(each.value.secrets_manager.arn, null) : null
  secrets_manager_access_role_arn = try(each.value.auth_mode, "secrets_manager") == "secrets_manager" ? try(each.value.secrets_manager.role_arn, null) : null

  extra_connection_attributes = try(
    join(";", [for k, v in try(each.value.extra_connection_attributes, {}) : "${k}=${v}"]),
    try(each.value.extra_connection_attributes, null)
  )

  tags = local.merged_tags
}

#########################################
# DMS Endpoints - Targets
#########################################

resource "aws_dms_endpoint" "target" {
  for_each = var.target_endpoints

  endpoint_id   = each.key
  endpoint_type = "target"
  engine_name   = each.value.engine_name

  server_name   = try(each.value.server_name, null)
  port          = try(each.value.port, null)
  database_name = try(each.value.database_name, null)
  username      = try(each.value.auth_mode, "secrets_manager") == "basic" ? try(each.value.username, null) : null
  password      = try(each.value.auth_mode, "secrets_manager") == "basic" ? try(each.value.password, null) : null

  secrets_manager_arn             = try(each.value.auth_mode, "secrets_manager") == "secrets_manager" ? try(each.value.secrets_manager.arn, null) : null
  secrets_manager_access_role_arn = try(each.value.auth_mode, "secrets_manager") == "secrets_manager" ? try(each.value.secrets_manager.role_arn, null) : null

  extra_connection_attributes = try(
    join(";", [for k, v in try(each.value.extra_connection_attributes, {}) : "${k}=${v}"]),
    try(each.value.extra_connection_attributes, null)
  )

  tags = local.merged_tags
}

#########################################
# DMS Replication Tasks
#########################################

resource "aws_dms_replication_task" "task" {
  for_each = var.replication_tasks

  replication_task_id      = each.key
  migration_type           = each.value.migration_type
  replication_instance_arn = aws_dms_replication_instance.this.replication_instance_arn

  source_endpoint_arn = aws_dms_endpoint.source[each.value.source_endpoint_id].endpoint_arn
  target_endpoint_arn = aws_dms_endpoint.target[each.value.target_endpoint_id].endpoint_arn

  table_mappings            = jsonencode(each.value.table_mappings)
  replication_task_settings = try(jsonencode(each.value.replication_task_settings), null)

  tags = local.merged_tags
}

#########################################
# DMS Premigration Assessments
#########################################

resource "aws_dms_replication_task" "premigration" {
  for_each = var.assessments

  replication_task_id      = each.key
  migration_type           = "full-load" # required field; assessment controlled by settings
  replication_instance_arn = aws_dms_replication_instance.this.replication_instance_arn

  source_endpoint_arn = aws_dms_endpoint.source[each.value.source_endpoint_id].endpoint_arn
  target_endpoint_arn = aws_dms_endpoint.target[each.value.target_endpoint_id].endpoint_arn

  table_mappings = jsonencode(each.value.table_mappings)

  replication_task_settings = jsonencode(
    merge(
      try(each.value.assessment_settings, {}),
      local.assessment_bucket_name != null ? { S3BucketName = local.assessment_bucket_name } : {}
    )
  )

  tags = local.merged_tags
}
