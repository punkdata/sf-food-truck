# Example 7: Inline JSON — Define mappings directly in Terraform (HCL-native JSON)

module "dms" {
  source = "../"

  name_prefix                  = "example-inline-json"
  replication_instance_class   = "dms.t3.medium"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  # Let module create a KMS key
  create_kms_key = true

  source_endpoints = {
    src1 = {
      engine_name   = "postgres"
      server_name   = "src-db.local"
      port          = 5432
      database_name = "sourcedb"
      auth_mode     = "basic"
      username      = "user"
      password      = "pass"
  subnet_ids = ["subnet-12345678", "subnet-abcdef12"]
    }
  }

  target_endpoints = {
    tgt1 = {
      engine_name   = "postgres"
      server_name   = "tgt-db.local"
      port          = 5432
      database_name = "targetdb"
      auth_mode     = "basic"
      username      = "user"
      password      = "pass"
    }
  }

  replication_tasks = {
    task1 = {
      migration_type     = "full-load"
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"

      # HCL-native JSON inline
      table_mappings = {
        rules = [{
          rule-type     = "selection"
          rule-id       = "1"
          rule-name     = "include_all"
          object-locator = {
            schema-name = "public"
            table-name  = "%"
          }
          rule-action = "include"
        }]
      }

      replication_task_settings = {
        FullLoadSettings = {
          TargetTablePrepMode = "DROP_AND_CREATE"
        }
      }
    }
  }
}