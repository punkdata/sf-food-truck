# Example 9: Combined Inline and File-based JSON
#
# This example demonstrates how to configure multiple replication tasks
# within the same DMS instance, where:
#   - Task 1 uses inline JSON (convenient for quick prototyping).
#   - Task 2 uses file-based JSON (recommended for production).
#
# This hybrid approach allows teams to experiment quickly
# while keeping complex, production-grade task definitions
# in external JSON files for clarity and version control.

module "dms" {
  source = "../"

  # ----------------------------
  # Required module inputs
  # ----------------------------
  name_prefix                = "example-combined-json"
  replication_instance_class = "dms.t3.medium"

  subnet_ids             = ["subnet-0123456789abcdef0", "subnet-abcdef0123456789"]
  vpc_security_group_ids = ["sg-0123456789abcdef0"]

  # ----------------------------
  # Endpoints (one source, one target)
  # ----------------------------
  source_endpoints = {
    src1 = {
      engine_name   = "postgres"
      server_name   = "src-db.local"
      port          = 5432
      database_name = "sourcedb"
      auth_mode     = "basic"
      username      = "user"
      password      = "pass"
    }
  }

  target_endpoints = {
    tgt1 = {
      engine_name   = "postgres"
      server_name   = "tgt-db.local"
      port          = 5432
      database_name = "targetdb"
      auth_mode     = "basic"
      username      = "admin"
      password      = "password123"
    }
  }

  # ----------------------------
  # Replication Tasks
  # ----------------------------
  replication_tasks = {
    # ----------------------------
    # Task 1: Inline JSON
    # ----------------------------
    inline_task = {
      migration_type     = "full-load"
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"

      # Inline table mappings
      table_mappings = <<EOT
{
  "rules": [
    {
      "rule-type": "selection",
      "rule-id": "1",
      "rule-name": "include_all",
      "object-locator": {
        "schema-name": "%",
        "table-name": "%"
      },
      "rule-action": "include"
    }
  ]
}
EOT

      # Inline replication task settings
      replication_task_settings = <<EOT
{
  "Logging": {
    "EnableLogging": true
  },
  "CreateTargetMetadata": {
    "TargetSchema": "public",
    "SupportLobs": true,
    "PrimaryKey": true,
    "UniqueConstraints": true,
    "ForeignKeys": true,
    "Indexes": true
  },
  "FullLoadSettings": {
    "TargetTablePrepMode": "DROP_AND_CREATE"
  }
}
EOT
    }

    # ----------------------------
    # Task 2: File-based JSON
    # ----------------------------
    file_task = {
      migration_type     = "full-load"
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"

      # Table mappings loaded from external file
      table_mappings = file("${path.module}/mappings/task1-mapping.json")

      # Replication task settings loaded from external file
      replication_task_settings = file("${path.module}/settings/task1-settings.json")
    }
  }
}