# Example 3: Multi-Endpoint — Multiple Sources + Multiple Targets (with Logs S3 + IAM Roles)
module "dms" {
  source = "../"

  name_prefix                  = "example-multi-endpoint"
  replication_instance_class   = "dms.t3.medium"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  # Enable S3 bucket for logs
  create_logs_s3_bucket = true

  # Create IAM roles for DMS
  create_dms_roles = true
  iam_role_path    = "/role/dms/"

  # KMS created by module
  create_kms_key = true

  # Multiple sources
  source_endpoints = {
    src1 = { engine_name = "mysql",   server_name = "src1-db.local", port = 3306, database_name = "db1", auth_mode = "basic", username = "user", password = "pass" }
    src2 = { engine_name = "oracle",  server_name = "src2-db.local", port = 1521, database_name = "db2", auth_mode = "basic", username = "user", password = "pass" }
  subnet_ids = ["subnet-12345678", "subnet-abcdef12"]
  }

  # Multiple targets
  target_endpoints = {
    tgt1 = { engine_name = "postgres", server_name = "tgt1-db.local", port = 5432, database_name = "dbtarget1", auth_mode = "basic", username = "admin", password = "pass" }
    tgt2 = { engine_name = "postgres", server_name = "tgt2-db.local", port = 5432, database_name = "dbtarget2", auth_mode = "basic", username = "admin", password = "pass" }
  }

  replication_tasks = {
    task1 = {
      migration_type     = "full-load"
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"
      table_mappings     = { rules = [] }
    }
  }
}