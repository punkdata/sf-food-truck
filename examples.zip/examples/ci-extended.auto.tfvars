# 🔹 Extended CI/CD safe tfvars
# Demonstrates a more production-ready configuration with optional features.

replication_instance_class = "dms.t3.medium"

subnet_ids = [
  "subnet-0123456789abcdef0",
  "subnet-abcdef0123456789"
]

vpc_security_group_ids = ["sg-0123456789abcdef0"]

tags = {
  Environment = "staging"
  Owner       = "data-migration-team"
  Project     = "customer-migration"
}

iam_role_path = "/service-role/"
create_dms_roles = false

# Encryption everywhere
kms_key_arn = "arn:aws:kms:us-east-1:123456789012:key/11111111-2222-3333-4444-555555555555"

# Ensure logs are created and encrypted
create_cw_logs = true

# Optional S3 buckets for assessments and logs
create_assessment_s3_bucket = true
create_logs_s3_bucket       = true
s3_force_destroy            = false

# Example endpoints (OPA safe: Secrets Manager, not plaintext)
source_endpoints = {
  src1 = {
    engine_name     = "postgres"
    auth_mode       = "secrets_manager"
    secrets_manager = {
      arn      = "arn:aws:secretsmanager:us-east-1:123456789012:secret:src1"
      role_arn = "arn:aws:iam::123456789012:role/dms-secret-role"
    }
  }
}

target_endpoints = {
  tgt1 = {
    engine_name     = "postgres"
    auth_mode       = "secrets_manager"
    secrets_manager = {
      arn      = "arn:aws:secretsmanager:us-east-1:123456789012:secret:tgt1"
      role_arn = "arn:aws:iam::123456789012:role/dms-secret-role"
    }
  }
}

# Example replication tasks
replication_tasks = {
  task1 = {
    source_endpoint_arn = "arn:aws:dms:us-east-1:123456789012:endpoint:SRC1"
    target_endpoint_arn = "arn:aws:dms:us-east-1:123456789012:endpoint:TGT1"
    migration_type      = "full-load"
    table_mappings      = file("examples/json/table-mappings.json")
  }
}

# Example premigration assessments
assessments = {
  assess1 = {
    replication_instance_arn = "arn:aws:dms:us-east-1:123456789012:rep:MYINSTANCE"
    assessment_name          = "precheck-task1"
    task_settings            = file("examples/json/assessment-settings.json")
  }
}
name_prefix = "example-dms-"
