# Example 2: Multi-Task — One Source + One Target + Multiple Tasks (with CloudWatch logs)
module "dms" {
  source = "../"

  name_prefix                  = "example-multi-task"
  replication_instance_class   = "dms.t3.medium"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  # Enable CloudWatch logs with retention
  create_cw_logs               = true
  cw_log_group_retention_days  = 14

  # Module-managed KMS
  create_kms_key = true

  # Source endpoint with Secrets Manager
  source_endpoints = {
    src1 = {
      engine_name   = "postgres"
      server_name   = "src-db.local"
      port          = 5432
      database_name = "sourcedb"
      auth_mode     = "secrets_manager"
      secrets_manager = {
        arn      = "arn:aws:secretsmanager:us-east-1:123456789012:secret:src1"
        role_arn = "arn:aws:iam::123456789012:role/dms-secret-role"
  subnet_ids = ["subnet-12345678", "subnet-abcdef12"]
      }
    }
  }

  # Target endpoint
  target_endpoints = {
    tgt1 = {
      engine_name   = "postgres"
      server_name   = "tgt-db.local"
      port          = 5432
      database_name = "targetdb"
      auth_mode     = "basic"
      username      = "admin"
      password      = "password123"
    }
  }

  # Multiple tasks
  replication_tasks = {
    full_load = {
      migration_type     = "full-load"
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"
      table_mappings     = { rules = [] }
    }
    cdc = {
      migration_type     = "cdc"
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"
      table_mappings     = { rules = [] }
    }
  }
}