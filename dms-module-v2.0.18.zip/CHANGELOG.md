# Changelog

## Added
- Support for multiple replication tasks per DMS replication instance.
- Support for multiple source and target endpoints.
- Support for premigration assessment tasks.
- Example JSON files for table mappings, endpoint settings, and task settings.
- Examples directory with progressively complex scenarios (basic, assessment, CI/CD friendly, etc.).
- New `examples/10-ci-friendly.auto.tfvars` demonstrating how to configure the module safely in CI/CD pipelines without interactive prompts.

## Changed
- Switched from `replication_subnet_group_name` to `subnet_ids`; the module now always creates a replication subnet group.
- IAM roles use strict AWS-required names (`dms-vpc-role`, `dms-cloudwatch-logs-role`, `dms-access-for-endpoint`) by default.
- Introduced `create_dms_roles` toggle (default = `false`) to avoid IAM `EntityAlreadyExists` errors in accounts where roles already exist.
- Updated `locals.tf` to include both **global** and **regional** service principals for DMS, S3, Kinesis, and CloudWatch.
- Replaced deprecated `data.aws_region.current.name` with `data.aws_region.current.id`.
- Improved validation logic:
  - `tags` must include an `Environment` key.
  - `kms_key_arn` is required if CloudWatch logs are enabled.
- Updated examples to prefer AWS Secrets Manager for credentials instead of plaintext passwords (OPA compliance).
- README expanded with detailed sections:
  - Features
  - Usage
  - Basic Example
  - Premigration Assessment Example
  - Outputs
  - Important Notes
  - KMS Keys
  - S3 Buckets
  - CI/CD Friendly Example

## Security / Compliance
- Added S3 Public Access Block resources for both assessment and logs buckets.
- Enabled S3 versioning by default on both assessment and logs buckets.
- Made S3 bucket `force_destroy` configurable via new `s3_force_destroy` variable (default = `false`).
- Ensured CloudWatch log groups can be encrypted with KMS keys.
- Default behavior aligns with common OPA/Conftest policies (no public buckets, encryption required, tags enforced).

## Fixed
- Removed dangling references to deprecated or unused variables (`strict_dms_role_names`).
- Corrected IAM role policies to match AWS-managed service roles.
- Fixed broken or missing anchors in the README file.
