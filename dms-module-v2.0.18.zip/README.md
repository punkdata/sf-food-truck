# DMS Module v2.0.0

This Terraform module provisions an AWS Database Migration Service (DMS) environment, including:

- Replication instance
- Source and target endpoints (multi-endpoint supported)
- Replication tasks (multi-task supported)
- Premigration assessment tasks
- Optional S3 buckets (for assessment reports and task logs)
- Optional CloudWatch log group
- Optional IAM roles for DMS
- Optional KMS CMK (default: create one)

---

## Table of Contents
- [Features](#features)
- [Usage](#usage)
  - [Basic Example](#basic-example-replication-instance--endpoints--task)
  - [Premigration Assessment Example](#premigration-assessment-example)
- [Variables](#variables)
- [Outputs](#outputs)
- [Important Notes](#important-notes)
  - [IAM Roles (`create_dms_roles`)](#iam-roles-createdms_roles)
  - [KMS Keys (`kms_key_arn--create_kms_key`)](#kms-keys-kms_key_arn--create_kms_key)
  - [S3 Buckets (`create_assessment_s3_bucket-create_logs_s3_bucket`)](#s3-buckets-create_assessment_s3_bucket-create_logs_s3_bucket)

---

## Features

- Multiple endpoints (maps for `source_endpoints` and `target_endpoints`)
- Multiple tasks (maps for `replication_tasks`)
- Native JSON support for `table_mappings` and `replication_task_settings`
- Premigration assessments with optional dedicated S3 bucket
- KMS CMK encryption for all resources (buckets, logs, tasks, replication instance)
- Configurable IAM role path (default: `/role/dms/`)
- Optional resource creation flags (IAM roles, S3 buckets, CloudWatch log group)

---

## Usage

### Basic Example (Replication Instance + Endpoints + Task)

```hcl
module "dms" {
  source = "./dms-module"

  name_prefix                  = "example"
  replication_instance_class   = "dms.t3.medium"
  replication_subnet_group_name = "my-dms-subnet-group"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  source_endpoints = {
    src1 = {
      engine_name   = "postgres"
      server_name   = "source-db.example.com"
      port          = 5432
      database_name = "sourcedb"
      auth_mode     = "secrets_manager"
      secrets_manager = {
        arn      = "arn:aws:secretsmanager:us-east-1:123456789012:secret:src1"
        role_arn = "arn:aws:iam::123456789012:role/secrets-role"
      }
    }
  }

  target_endpoints = {
    tgt1 = {
      engine_name   = "postgres"
      server_name   = "target-db.example.com"
      port          = 5432
      database_name = "targetdb"
      auth_mode     = "basic"
      username      = "admin"
      password      = "SuperSecretPassw0rd"
    }
  }

  replication_tasks = {
    task1 = {
      migration_type           = "full-load"
      source_endpoint_id       = "src1"
      target_endpoint_id       = "tgt1"
      table_mappings           = {
        rules = [{
          rule-type = "selection"
          rule-id   = "1"
          rule-name = "1"
          object-locator = {
            schema-name = "public"
            table-name  = "%"
          }
          rule-action = "include"
        }]
      }
      replication_task_settings = {
        TargetMetadata = {
          TargetSchema = ""
        }
      }
    }
  }
}
```

### Premigration Assessment Example

```hcl
module "dms" {
  source = "./dms-module"

  name_prefix                  = "example"
  replication_instance_class   = "dms.t3.medium"
  replication_subnet_group_name = "my-dms-subnet-group"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  create_assessment_s3_bucket = true

  premigration_assessments = {
    assess1 = {
      source_endpoint_id  = "src1"
      target_endpoint_id  = "tgt1"
      table_mappings      = {
        rules = [{
          rule-type = "selection"
          rule-id   = "1"
          rule-name = "1"
          object-locator = {
            schema-name = "public"
            table-name  = "%"
          }
          rule-action = "include"
        }]
      }
      assessment_settings = {
        EnableAssessmentRun = true
      }
    }
  }
}
```

| Name                            | Type         | Required | Default      | Description                                                                                     |
| ------------------------------- | ------------ | -------- | ------------ | ----------------------------------------------------------------------------------------------- |
| `name_prefix`                   | string       | Yes      | n/a          | Prefix for resource names (<= 46 chars, lowercase alphanumeric + hyphens).                      |
| `tags`                          | map(string)  | No       | `{}`         | Tags to apply to all resources.                                                                 |
| `replication_subnet_group_name` | string       | Yes      | n/a          | Existing DMS replication subnet group name.                                                     |
| `vpc_security_group_ids`        | list(string) | Yes      | n/a          | Security group IDs for replication instance.                                                    |
| `kms_key_arn`                   | string       | No       | `null`       | Use existing KMS CMK. If `null` and `create_kms_key=true`, a new key is created.                |
| `create_kms_key`                | bool         | No       | `true`       | Whether to create a new KMS CMK.                                                                |
| `create_dms_roles`              | bool         | No       | `true`       | Create DMS IAM roles (`dms-vpc-role`, `dms-cloudwatch-logs-role`). See notes below for details. |
| `iam_role_path`                 | string       | No       | `/role/dms/` | IAM path for DMS roles. Useful if OPA enforces custom IAM paths.                                |
| `create_assessment_s3_bucket`   | bool         | No       | `true`       | Create S3 bucket for assessment reports.                                                        |
| `create_logs_s3_bucket`         | bool         | No       | `false`      | Create S3 bucket for task logs.                                                                 |
| `create_cw_logs`                | bool         | No       | `false`      | Create CloudWatch Log Group for DMS tasks.                                                      |
| `cw_log_group_retention_days`   | number       | No       | `30`         | Retention days for CloudWatch logs.                                                             |
| `source_endpoints`              | map(any)     | No       | `{}`         | Map of source endpoint definitions (supports Secrets Manager or basic auth).                    |
| `target_endpoints`              | map(any)     | No       | `{}`         | Map of target endpoint definitions.                                                             |
| `replication_tasks`             | map(any)     | No       | `{}`         | Map of replication tasks (must reference valid endpoints).                                      |
| `premigration_assessments`      | map(any)     | No       | `{}`         | Map of premigration assessment tasks.                                                           |
| `replication_instance_class`    | string       | Yes      | n/a          | Instance class for replication instance (e.g., `dms.t3.medium`).                                |
| `allocated_storage`             | number       | No       | `50`         | Allocated storage (GiB).                                                                        |
| `apply_immediately`             | bool         | No       | `true`       | Apply changes immediately.                                                                      |
| `publicly_accessible`           | bool         | No       | `false`      | Whether instance is public.                                                                     |
| `auto_minor_version_upgrade`    | bool         | No       | `true`       | Enable automatic minor version upgrades.                                                        |
| `allow_major_version_upgrade`   | bool         | No       | `false`      | Allow major version upgrades.                                                                   |
| `preferred_maintenance_window`  | string       | No       | `null`       | Maintenance window (e.g., `sun:03:00-sun:04:00`).                                               |

### Outputs

| Name                                | Description                                                |
| ----------------------------------- | ---------------------------------------------------------- |
| `account_id`                        | AWS account ID.                                            |
| `region`                            | AWS region.                                                |
| `partition`                         | AWS partition (e.g., `aws`, `aws-us-gov`).                 |
| `kms_key_arn`                       | ARN of the KMS CMK used for encryption.                    |
| `replication_instance_id`           | ID of the DMS replication instance.                        |
| `replication_instance_arn`          | ARN of the DMS replication instance.                       |
| `source_endpoints`                  | Map of source endpoint ARNs keyed by endpoint ID.          |
| `target_endpoints`                  | Map of target endpoint ARNs keyed by endpoint ID.          |
| `replication_task_ids`              | Map of replication task IDs.                               |
| `replication_task_arns`             | Map of replication task ARNs.                              |
| `premigration_assessment_task_arns` | Map of premigration assessment task ARNs.                  |
| `assessment_s3_bucket_name`         | Name of the S3 bucket for assessment reports (if created). |
| `logs_s3_bucket_name`               | Name of the S3 bucket for task logs (if created).          |
| `dms_vpc_role_arn`                  | ARN of the DMS VPC IAM role (if created).                  |
| `dms_cloudwatch_logs_role_arn`      | ARN of the DMS CloudWatch Logs IAM role (if created).      |

## Important Notes

## Important Notes

### IAM Roles (`create_dms_roles`)
- **Default = `false`** → safest for most environments.  
  - Prevents Terraform from trying to recreate roles that may already exist in the account.  
  - Avoids AWS API error: `EntityAlreadyExists`.  
- Set to `true` only once when bootstrapping a brand-new account or region where these roles do not yet exist.  
- Once roles exist, keep this flag set to `false` for subsequent runs.  
- Required IAM roles:  
  - `dms-vpc-role`  
  - `dms-cloudwatch-logs-role`  
  - `dms-access-for-endpoint`  

### KMS Keys (`kms_key_arn / create_kms_key`)
- All DMS resources (replication instance, S3 buckets, CloudWatch logs) require encryption at rest.  
- **`create_kms_key = true`** → module generates a CMK (good for dev/test).  
- **Provide `kms_key_arn`** → use an existing CMK (required in production with strict compliance).  
- Best practice in production: use customer-managed keys with rotation and explicit key policies.  

### S3 Buckets (`create_assessment_s3_bucket`, `create_logs_s3_bucket`)
- Module can create S3 buckets for assessments and logs.  
- Buckets created by the module include:  
  - Versioning enabled  
  - KMS encryption enabled  
  - Public access blocked  
  - TLS-only policy enforced  
- **Enable creation (true)** → dev/test accounts for quick setup.  
- **Disable creation (false)** → production accounts with centrally managed buckets.  


## CI/CD Friendly Examples

For automated pipelines, you don’t want Terraform to pause waiting for input
or fail OPA checks unnecessarily. This module includes two ready-to-use
`.auto.tfvars` files in the `examples/` directory.

### Minimal Example
Use `ci-minimal.auto.tfvars` for the bare minimum required to get a DMS replication instance running.

```hcl
terraform apply -var-file="examples/ci-minimal.auto.tfvars"
```

### Extended Example
Use `ci-extended.auto.tfvars` for a more production-ready setup with
encryption, Secrets Manager endpoints, premigration assessments, and S3 logs.

```hcl
terraform apply -var-file="examples/ci-extended.auto.tfvars"
```


