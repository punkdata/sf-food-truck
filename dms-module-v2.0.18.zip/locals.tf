locals {
  # AWS context
  account_id = data.aws_caller_identity.current.account_id
  region     = data.aws_region.current.id
  partition  = data.aws_partition.current.dns_suffix

  # DMS IAM role names — AWS requires these exact values
  dms_role_names = {
    vpc        = "dms-vpc-role"
    cloudwatch = "dms-cloudwatch-logs-role"
    access     = "dms-access-for-endpoint"
  }

  # AWS Service Principals (for trust policies)
  service_principals = {
    # global
    dms_global     = "dms.amazonaws.com"
    logs_global    = "logs.amazonaws.com"
    s3_global      = "s3.amazonaws.com"
    kinesis_global = "kinesis.amazonaws.com"

    # regional
    dms_regional     = "dms.${local.region}.${local.partition}"
    logs_regional    = "logs.${local.region}.${local.partition}"
    s3_regional      = "s3.${local.region}.${local.partition}"
    kinesis_regional = "kinesis.${local.region}.${local.partition}"
  }
}


#############################################
# Newly enforced locals for consistency     #
#############################################

locals {
  account_root_arn       = "arn:aws:iam::${local.account_id}:root"
  assessment_bucket_name = try(aws_s3_bucket.assessment[0].bucket, null)
  logs_bucket_name       = try(aws_s3_bucket.logs[0].bucket, null)
  kms_arn                = var.kms_key_arn
  merged_tags            = merge(var.tags, { Module = "dms" })
  subnet_group_name      = aws_dms_replication_subnet_group.this.id
}
