output "replication_instance_arn" {
  value = aws_dms_replication_instance.this.replication_instance_arn
}

output "replication_instance_id" {
  value = aws_dms_replication_instance.this.replication_instance_id
}

output "source_endpoint_arns" {
  value = { for k, v in aws_dms_endpoint.source : k => v.endpoint_arn }
}

output "target_endpoint_arns" {
  value = { for k, v in aws_dms_endpoint.target : k => v.endpoint_arn }
}

output "replication_task_arns" {
  value = { for k, v in aws_dms_replication_task.task : k => v.replication_task_arn }
}

output "premigration_assessment_task_arns" {
  value = { for k, v in aws_dms_replication_task.premigration : k => v.replication_task_arn }
}

output "replication_subnet_group_id" {
  value = aws_dms_replication_subnet_group.this.id
}
