variable "name_prefix" {
  description = "Prefix for resource names."
  type        = string
  validation {
    condition     = length(var.name_prefix) <= 46 && can(regex("^[a-z0-9]+(-[a-z0-9]+)*$", var.name_prefix))
    error_message = "name_prefix must be lowercase alphanumeric with hyphens, <= 46 characters."
  }
}

variable "tags" {
  description = "Tags to apply to all resources."
  type        = map(string)
  default     = {}
}

variable "subnet_ids" {
  description = "List of VPC subnet IDs for the DMS replication subnet group"
  type        = list(string)

  validation {
    condition     = length(var.subnet_ids) > 0
    error_message = "You must provide at least one subnet ID."
  }
}

variable "vpc_security_group_ids" {
  description = "List of security group IDs for replication instance."
  type        = list(string)
}

variable "kms_key_arn" {
  description = "Use existing KMS key ARN instead of creating one."
  type        = string
  default     = null
}

variable "create_kms_key" {
  description = "Whether to create a new KMS CMK."
  type        = bool
  default     = true
}

variable "create_dms_roles" {
  description = "Whether to create DMS IAM roles."
  type        = bool
  default     = true
}

variable "create_assessment_s3_bucket" {
  description = "Whether to create S3 bucket for assessment tasks."
  type        = bool
  default     = true
}

variable "create_logs_s3_bucket" {
  description = "Whether to create S3 bucket for task logs."
  type        = bool
  default     = false
}

variable "s3_force_destroy" {
  description = "Whether to allow force destroy for S3 buckets created by this module."
  type        = bool
  default     = false
}

variable "create_cw_logs" {
  description = "Whether to create CloudWatch log group."
  type        = bool
  default     = false
}

variable "cw_log_group_retention_days" {
  description = "Retention days for CloudWatch Logs."
  type        = number
  default     = 30
}

variable "replication_instance_class" {
  description = "Instance class for the DMS replication instance (e.g., dms.t3.medium)."
  type        = string
}

variable "allocated_storage" {
  description = "Allocated storage (GiB)."
  type        = number
  default     = 50
}

variable "apply_immediately" {
  description = "Whether to apply modifications immediately."
  type        = bool
  default     = true
}

variable "publicly_accessible" {
  description = "Whether the instance is publicly accessible."
  type        = bool
  default     = false
}

variable "auto_minor_version_upgrade" {
  description = "Enable auto minor version upgrades."
  type        = bool
  default     = true
}

variable "allow_major_version_upgrade" {
  description = "Allow major version upgrades."
  type        = bool
  default     = false
}

variable "preferred_maintenance_window" {
  description = "Maintenance window. Leave null for default."
  type        = string
  default     = null
}

variable "iam_role_path" {
  description = "Path for DMS IAM roles (e.g., /role/dms/)."
  type        = string
  default     = "/role/dms/"
}

variable "source_endpoints" {
  description = "Map of DMS source endpoints"
  type = map(object({
    engine_name     = string
    endpoint_id     = optional(string)
    auth_mode       = optional(string, "secrets_manager")
    server_name     = optional(string)
    port            = optional(number)
    database_name   = optional(string)
    username        = optional(string)
    password        = optional(string)
    ssl_mode        = optional(string)
    secrets_manager = optional(object({
      arn      = string
      role_arn = string
    }))
    extra_connection_attributes = optional(map(string))
  }))
  default = {}
}

variable "target_endpoints" {
  description = "Map of DMS target endpoints"
  type = map(object({
    engine_name     = string
    endpoint_id     = optional(string)
    auth_mode       = optional(string, "secrets_manager")
    server_name     = optional(string)
    port            = optional(number)
    database_name   = optional(string)
    username        = optional(string)
    password        = optional(string)
    ssl_mode        = optional(string)
    secrets_manager = optional(object({
      arn      = string
      role_arn = string
    }))
    extra_connection_attributes = optional(map(string))
  }))
  default = {}
}

variable "replication_tasks" {
  description = "Map of replication tasks to create"
  type = map(object({
    source_endpoint_id        = string
    target_endpoint_id        = string
    migration_type            = string
    table_mappings            = any
    replication_task_id       = optional(string)
    replication_task_settings = optional(any)
  }))
  default = {}
}

variable "premigration_assessments" {
  description = "Map of premigration assessment tasks."
  type = map(object({
    source_endpoint_id  = string
    target_endpoint_id  = string
    table_mappings      = any
    assessment_settings = optional(map(any))
  }))
  default = {}
}
