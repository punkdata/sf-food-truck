locals {
  account_id = data.aws_caller_identity.current.account_id
  region     = data.aws_region.current.id
  partition  = data.aws_partition.current.dns_suffix

  account_root_arn = "arn:aws:iam::${local.account_id}:root"

  dms_role_names = {
    vpc        = "dms-vpc-role"
    cloudwatch = "dms-cloudwatch-logs-role"
    access     = "dms-access-for-endpoint"
  }

  service_principals = {
    dms_global     = "dms.amazonaws.com"
    logs_global    = "logs.amazonaws.com"
    s3_global      = "s3.amazonaws.com"
    kinesis_global = "kinesis.amazonaws.com"

    dms_regional     = "dms.${local.region}.${local.partition}"
    logs_regional    = "logs.${local.region}.${local.partition}"
    s3_regional      = "s3.${local.region}.${local.partition}"
    kinesis_regional = "kinesis.${local.region}.${local.partition}"
  }

  dms_service_principals = [
    "dms.${data.aws_partition.current.dns_suffix}",
    "dms.${data.aws_region.current.name}.${data.aws_partition.current.dns_suffix}"
  ]

  logs_service_principals = [
    "logs.${data.aws_partition.current.dns_suffix}",
    "logs.${data.aws_region.current.name}.${data.aws_partition.current.dns_suffix}"
  ]

  s3_service_principals = [
    "s3.${data.aws_partition.current.dns_suffix}",
    "s3.${data.aws_region.current.name}.${data.aws_partition.current.dns_suffix}"
  ]

  kms_service_principals = [
    "kms.${data.aws_partition.current.dns_suffix}",
    "kms.${data.aws_region.current.name}.${data.aws_partition.current.dns_suffix}"
  ]

  assessment_bucket_name = try(aws_s3_bucket.assessment[0].bucket, null)
  logs_bucket_name       = try(aws_s3_bucket.logs[0].bucket, null)
  kms_arn                = var.kms_key_arn
  merged_tags            = merge(var.tags, { Module = "dms" })
}
