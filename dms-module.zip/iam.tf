#########################################
# IAM Roles for DMS
#########################################

resource "aws_iam_role" "dms_vpc_role" {
  count              = var.create_dms_roles ? 1 : 0
  name               = "dms-vpc-role"
  path               = var.iam_role_path
  assume_role_policy = data.aws_iam_policy_document.dms_assume_role.json
}

resource "aws_iam_role" "dms_cloudwatch_logs_role" {
  count              = var.create_dms_roles ? 1 : 0
  name               = "dms-cloudwatch-logs-role"
  path               = var.iam_role_path
  assume_role_policy = data.aws_iam_policy_document.logs_assume_role.json
}

#########################################
# Assume Role Policies
#########################################

data "aws_iam_policy_document" "dms_assume_role" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = local.dms_service_principals
    }
  }
}

data "aws_iam_policy_document" "logs_assume_role" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = local.logs_service_principals
    }
  }
}

#########################################
# Inline Policies (broad, test mode)
#########################################

resource "aws_iam_role_policy" "dms_vpc_policy" {
  count = var.create_dms_roles ? 1 : 0
  name  = "dms-vpc-policy"
  role  = aws_iam_role.dms_vpc_role[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "ec2:CreateNetworkInterface",
        "ec2:DeleteNetworkInterface",
        "ec2:DescribeNetworkInterfaces",
        "ec2:ModifyNetworkInterfaceAttribute",
        "ec2:DescribeVpcs",
        "ec2:DescribeSubnets",
        "ec2:DescribeSecurityGroups",
        "ec2:DescribeDhcpOptions",
        "ec2:DescribeInternetGateways"
      ]
      Resource = "*"
    }]
  })
}

resource "aws_iam_role_policy" "dms_logs_policy" {
  count = var.create_dms_roles ? 1 : 0
  name  = "dms-logs-policy"
  role  = aws_iam_role.dms_cloudwatch_logs_role[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "logs:DescribeLogStreams"
      ]
      Resource = "*"
    }]
  })
}
