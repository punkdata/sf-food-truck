# Example 5: Full — Multi-Task + Endpoints + Assessment + S3 + CloudWatch + IAM Roles
module "dms" {
  source = "../"

  name_prefix                  = "example-full"
  replication_instance_class   = "dms.t3.medium"
  replication_subnet_group_name = "my-subnet-group"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  # Enable all optional features
  create_assessment_s3_bucket = true
  create_logs_s3_bucket       = true
  create_cw_logs              = true
  cw_log_group_retention_days = 30
  create_dms_roles            = true
  iam_role_path               = "/role/dms/"

  # Module-managed KMS
  create_kms_key = true

  source_endpoints = {
    src1 = { engine_name = "mysql", server_name = "src1-db.local", port = 3306, database_name = "db1", auth_mode = "basic", username = "user1", password = "pass1" }
  }

  target_endpoints = {
    tgt1 = { engine_name = "postgres", server_name = "tgt1-db.local", port = 5432, database_name = "dbt1", auth_mode = "basic", username = "admin", password = "pass" }
  }

  replication_tasks = {
    task1 = { migration_type = "full-load", source_endpoint_id = "src1", target_endpoint_id = "tgt1", table_mappings = { rules = [] } }
    task2 = { migration_type = "cdc",       source_endpoint_id = "src1", target_endpoint_id = "tgt1", table_mappings = { rules = [] } }
  }

  premigration_assessments = {
    assess1 = {
      source_endpoint_id  = "src1"
      target_endpoint_id  = "tgt1"
      table_mappings      = { rules = [] }
      assessment_settings = { EnableAssessmentRun = true }
    }
  }
}
