# Example 8: File-Based JSON — Load mappings and settings from external JSON files

module "dms" {
  source = "../"

  name_prefix                  = "example-file-json"
  replication_instance_class   = "dms.t3.medium"
  replication_subnet_group_name = "my-dms-subnet-group"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  # Let module create a KMS key
  create_kms_key = true

  source_endpoints = {
    src1 = {
      engine_name   = "postgres"
      server_name   = "src-db.local"
      port          = 5432
      database_name = "sourcedb"
      auth_mode     = "basic"
      username      = "user"
      password      = "pass"
    }
  }

  target_endpoints = {
    tgt1 = {
      engine_name   = "postgres"
      server_name   = "tgt-db.local"
      port          = 5432
      database_name = "targetdb"
      auth_mode     = "basic"
      username      = "user"
      password      = "pass"
    }
  }

  replication_tasks = {
    task1 = {
      migration_type     = "full-load"
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"

      # Load JSON mappings and settings from external files
      table_mappings            = jsondecode(file("${path.module}/mappings/task1-mapping.json"))
      replication_task_settings = jsondecode(file("${path.module}/settings/task1-settings.json"))
    }
  }
}
