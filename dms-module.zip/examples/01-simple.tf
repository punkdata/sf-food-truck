# Example 1: Simplified — Single Endpoint + Single Task (with KMS + Assessment S3)
module "dms" {
  source = "../"

  name_prefix                  = "example-simple"
  replication_instance_class   = "dms.t3.medium"
  replication_subnet_group_name = "my-subnet-group"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  # Let module manage KMS
  create_kms_key = true

  # Enable S3 bucket for premigration assessment reports
  create_assessment_s3_bucket = true

  # Source endpoint
  source_endpoints = {
    src1 = {
      engine_name   = "postgres"
      server_name   = "src-db.local"
      port          = 5432
      database_name = "sourcedb"
      auth_mode     = "basic"
      username      = "user"
      password      = "pass"
    }
  }

  # Target endpoint
  target_endpoints = {
    tgt1 = {
      engine_name   = "postgres"
      server_name   = "tgt-db.local"
      port          = 5432
      database_name = "targetdb"
      auth_mode     = "basic"
      username      = "user"
      password      = "pass"
    }
  }

  # One replication task
  replication_tasks = {
    task1 = {
      migration_type     = "full-load"
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"
      table_mappings     = { rules = [] }
    }
  }
}
