# Example 4: Multi-Task + Multi-Endpoint (with Bring Your Own KMS)
module "dms" {
  source = "../"

  name_prefix                  = "example-multi-task-endpoint"
  replication_instance_class   = "dms.t3.medium"
  replication_subnet_group_name = "my-subnet-group"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  # Use existing CMK (replace ARN below)
  create_kms_key = false
  kms_key_arn    = "arn:aws:kms:us-east-1:123456789012:key/abcd-1234"

  # Multiple sources
  source_endpoints = {
    src1 = { engine_name = "mysql",   server_name = "src1-db.local", port = 3306, database_name = "db1", auth_mode = "basic", username = "user1", password = "pass1" }
    src2 = { engine_name = "postgres", server_name = "src2-db.local", port = 5432, database_name = "db2", auth_mode = "basic", username = "user2", password = "pass2" }
  }

  # Multiple targets
  target_endpoints = {
    tgt1 = { engine_name = "postgres", server_name = "tgt1-db.local", port = 5432, database_name = "dbt1", auth_mode = "basic", username = "admin", password = "pass" }
    tgt2 = { engine_name = "postgres", server_name = "tgt2-db.local", port = 5432, database_name = "dbt2", auth_mode = "basic", username = "admin", password = "pass" }
  }

  replication_tasks = {
    task1 = { migration_type = "full-load", source_endpoint_id = "src1", target_endpoint_id = "tgt1", table_mappings = { rules = [] } }
    task2 = { migration_type = "cdc",       source_endpoint_id = "src2", target_endpoint_id = "tgt2", table_mappings = { rules = [] } }
  }
}
