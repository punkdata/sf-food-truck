# Example 6: Secrets Manager Only — Endpoints use Secrets Manager (with KMS + IAM Roles)
module "dms" {
  source = "../"

  name_prefix                  = "example-secrets-only"
  replication_instance_class   = "dms.t3.medium"
  replication_subnet_group_name = "my-subnet-group"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  # Module-managed KMS
  create_kms_key = true

  # Create IAM roles
  create_dms_roles = true

  # Source endpoint with Secrets Manager
  source_endpoints = {
    src1 = {
      engine_name     = "postgres"
      server_name     = "src1-db.local"
      port            = 5432
      database_name   = "db1"
      auth_mode       = "secrets_manager"
      secrets_manager = {
        arn      = "arn:aws:secretsmanager:us-east-1:123456789012:secret:src1"
        role_arn = "arn:aws:iam::123456789012:role/secrets-role"
      }
    }
  }

  # Target endpoint with Secrets Manager
  target_endpoints = {
    tgt1 = {
      engine_name     = "postgres"
      server_name     = "tgt-db.local"
      port            = 5432
      database_name   = "dbt1"
      auth_mode       = "secrets_manager"
      secrets_manager = {
        arn      = "arn:aws:secretsmanager:us-east-1:123456789012:secret:tgt1"
        role_arn = "arn:aws:iam::123456789012:role/secrets-role"
      }
    }
  }

  replication_tasks = {
    task1 = {
      migration_type     = "full-load-and-cdc"
      source_endpoint_id = "src1"
      target_endpoint_id = "tgt1"
      table_mappings     = { rules = [] }
    }
  }
}
