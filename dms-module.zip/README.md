# DMS Module v2.0.0

This Terraform module provisions an AWS Database Migration Service (DMS) environment, including:

- Replication instance
- Source and target endpoints (multi-endpoint supported)
- Replication tasks (multi-task supported)
- Premigration assessment tasks
- Optional S3 buckets (for assessment reports and task logs)
- Optional CloudWatch log group
- Optional IAM roles for DMS
- Optional KMS CMK (default: create one)

---

## Table of Contents
- [Features](#features)
- [Usage](#usage)
  - [Basic Example](#basic-example-replication-instance--endpoints--task)
  - [Premigration Assessment Example](#premigration-assessment-example)
- [Variables](#variables)
- [Outputs](#outputs)
- [Important Notes](#important-notes)
  - [IAM Roles (`create_dms_roles`)](#iam-roles-create_dms_roles)
  - [KMS Keys (`kms_key_arn--create_kms_key`)](#kms-keys-kms_key_arn--create_kms_key)
  - [S3 Buckets (`create_assessment_s3_bucket-create_logs_s3_bucket`)](#s3-buckets-create_assessment_s3_bucket-create_logs_s3_bucket)

---

## Features

- Multiple endpoints (maps for `source_endpoints` and `target_endpoints`)
- Multiple tasks (maps for `replication_tasks`)
- Native JSON support for `table_mappings` and `replication_task_settings`
- Premigration assessments with optional dedicated S3 bucket
- KMS CMK encryption for all resources (buckets, logs, tasks, replication instance)
- Configurable IAM role path (default: `/role/dms/`)
- Optional resource creation flags (IAM roles, S3 buckets, CloudWatch log group)

---

## Usage

### Basic Example (Replication Instance + Endpoints + Task)

```hcl
module "dms" {
  source = "./dms-module"

  name_prefix                  = "example"
  replication_instance_class   = "dms.t3.medium"
  replication_subnet_group_name = "my-dms-subnet-group"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  source_endpoints = {
    src1 = {
      engine_name   = "postgres"
      server_name   = "source-db.example.com"
      port          = 5432
      database_name = "sourcedb"
      auth_mode     = "secrets_manager"
      secrets_manager = {
        arn      = "arn:aws:secretsmanager:us-east-1:123456789012:secret:src1"
        role_arn = "arn:aws:iam::123456789012:role/secrets-role"
      }
    }
  }

  target_endpoints = {
    tgt1 = {
      engine_name   = "postgres"
      server_name   = "target-db.example.com"
      port          = 5432
      database_name = "targetdb"
      auth_mode     = "basic"
      username      = "admin"
      password      = "SuperSecretPassw0rd"
    }
  }

  replication_tasks = {
    task1 = {
      migration_type           = "full-load"
      source_endpoint_id       = "src1"
      target_endpoint_id       = "tgt1"
      table_mappings           = {
        rules = [{
          rule-type = "selection"
          rule-id   = "1"
          rule-name = "1"
          object-locator = {
            schema-name = "public"
            table-name  = "%"
          }
          rule-action = "include"
        }]
      }
      replication_task_settings = {
        TargetMetadata = {
          TargetSchema = ""
        }
      }
    }
  }
}
```

### Premigration Assessment Example

```hcl
module "dms" {
  source = "./dms-module"

  name_prefix                  = "example"
  replication_instance_class   = "dms.t3.medium"
  replication_subnet_group_name = "my-dms-subnet-group"
  vpc_security_group_ids       = ["sg-0123456789abcdef0"]

  create_assessment_s3_bucket = true

  premigration_assessments = {
    assess1 = {
      source_endpoint_id  = "src1"
      target_endpoint_id  = "tgt1"
      table_mappings      = {
        rules = [{
          rule-type = "selection"
          rule-id   = "1"
          rule-name = "1"
          object-locator = {
            schema-name = "public"
            table-name  = "%"
          }
          rule-action = "include"
        }]
      }
      assessment_settings = {
        EnableAssessmentRun = true
      }
    }
  }
}
```

| Name                            | Type         | Required | Default      | Description                                                                                     |
| ------------------------------- | ------------ | -------- | ------------ | ----------------------------------------------------------------------------------------------- |
| `name_prefix`                   | string       | Yes      | n/a          | Prefix for resource names (<= 46 chars, lowercase alphanumeric + hyphens).                      |
| `tags`                          | map(string)  | No       | `{}`         | Tags to apply to all resources.                                                                 |
| `replication_subnet_group_name` | string       | Yes      | n/a          | Existing DMS replication subnet group name.                                                     |
| `vpc_security_group_ids`        | list(string) | Yes      | n/a          | Security group IDs for replication instance.                                                    |
| `kms_key_arn`                   | string       | No       | `null`       | Use existing KMS CMK. If `null` and `create_kms_key=true`, a new key is created.                |
| `create_kms_key`                | bool         | No       | `true`       | Whether to create a new KMS CMK.                                                                |
| `create_dms_roles`              | bool         | No       | `true`       | Create DMS IAM roles (`dms-vpc-role`, `dms-cloudwatch-logs-role`). See notes below for details. |
| `iam_role_path`                 | string       | No       | `/role/dms/` | IAM path for DMS roles. Useful if OPA enforces custom IAM paths.                                |
| `create_assessment_s3_bucket`   | bool         | No       | `true`       | Create S3 bucket for assessment reports.                                                        |
| `create_logs_s3_bucket`         | bool         | No       | `false`      | Create S3 bucket for task logs.                                                                 |
| `create_cw_logs`                | bool         | No       | `false`      | Create CloudWatch Log Group for DMS tasks.                                                      |
| `cw_log_group_retention_days`   | number       | No       | `30`         | Retention days for CloudWatch logs.                                                             |
| `source_endpoints`              | map(any)     | No       | `{}`         | Map of source endpoint definitions (supports Secrets Manager or basic auth).                    |
| `target_endpoints`              | map(any)     | No       | `{}`         | Map of target endpoint definitions.                                                             |
| `replication_tasks`             | map(any)     | No       | `{}`         | Map of replication tasks (must reference valid endpoints).                                      |
| `premigration_assessments`      | map(any)     | No       | `{}`         | Map of premigration assessment tasks.                                                           |
| `replication_instance_class`    | string       | Yes      | n/a          | Instance class for replication instance (e.g., `dms.t3.medium`).                                |
| `allocated_storage`             | number       | No       | `50`         | Allocated storage (GiB).                                                                        |
| `apply_immediately`             | bool         | No       | `true`       | Apply changes immediately.                                                                      |
| `publicly_accessible`           | bool         | No       | `false`      | Whether instance is public.                                                                     |
| `auto_minor_version_upgrade`    | bool         | No       | `true`       | Enable automatic minor version upgrades.                                                        |
| `allow_major_version_upgrade`   | bool         | No       | `false`      | Allow major version upgrades.                                                                   |
| `preferred_maintenance_window`  | string       | No       | `null`       | Maintenance window (e.g., `sun:03:00-sun:04:00`).                                               |

### Outputs

| Name                                | Description                                                |
| ----------------------------------- | ---------------------------------------------------------- |
| `account_id`                        | AWS account ID.                                            |
| `region`                            | AWS region.                                                |
| `partition`                         | AWS partition (e.g., `aws`, `aws-us-gov`).                 |
| `kms_key_arn`                       | ARN of the KMS CMK used for encryption.                    |
| `replication_instance_id`           | ID of the DMS replication instance.                        |
| `replication_instance_arn`          | ARN of the DMS replication instance.                       |
| `source_endpoints`                  | Map of source endpoint ARNs keyed by endpoint ID.          |
| `target_endpoints`                  | Map of target endpoint ARNs keyed by endpoint ID.          |
| `replication_task_ids`              | Map of replication task IDs.                               |
| `replication_task_arns`             | Map of replication task ARNs.                              |
| `premigration_assessment_task_arns` | Map of premigration assessment task ARNs.                  |
| `assessment_s3_bucket_name`         | Name of the S3 bucket for assessment reports (if created). |
| `logs_s3_bucket_name`               | Name of the S3 bucket for task logs (if created).          |
| `dms_vpc_role_arn`                  | ARN of the DMS VPC IAM role (if created).                  |
| `dms_cloudwatch_logs_role_arn`      | ARN of the DMS CloudWatch Logs IAM role (if created).      |

Important Notes

IAM Roles (create_dms_roles)

This flag controls whether the module creates the AWS Identity and Access Management (IAM) roles required by DMS:

dms-vpc-role → allows DMS to manage Elastic Network Interfaces (ENIs) in your VPC.

dms-cloudwatch-logs-role → allows DMS to write task logs into CloudWatch Logs.

When to set create_dms_roles = true

Use in development or test environments where the required roles do not exist.

Useful for self-contained deployments where the module provisions everything needed to run.

Appropriate for proof-of-concept migrations where IAM governance is relaxed.

When to set create_dms_roles = false

Use in production or governed accounts where IAM roles must be centrally managed.

Required if your organization enforces IAM via Control Tower, AFT, or central security policies.

Ensures you are not introducing duplicate or non-compliant roles into a production environment.

Scenarios

Development/Test Account → true (module creates roles).

Production Account → false (use pre-approved roles provided by IAM/Security team).

Multi-Account Migration → often requires cross-account trust; roles should be created and managed centrally, so false is recommended.

KMS Keys (kms_key_arn / create_kms_key)

All DMS resources (replication instance, S3 buckets, CloudWatch logs) require encryption at rest.

This module supports Customer Managed Keys (CMKs) by default.

When to let the module create a KMS key (create_kms_key = true)

Use when testing in an isolated account and you do not already have a CMK available.

Simplifies setup, as the module generates a CMK and alias automatically.

Appropriate for prototyping or ephemeral environments.

When to bring your own CMK (kms_key_arn supplied, create_kms_key = false)

Use in production where KMS keys are centrally managed.

Ensures compliance with organizational standards such as:

Rotation policies (automatic or manual).

Key policies with scoped principals.

Audit visibility in KMS usage.

Required if your security team enforces specific key policies or mandates key reuse across services.

Scenarios

Development/Test Account → let the module create the CMK (create_kms_key = true).

Production Account → provide an existing CMK (kms_key_arn = "arn:aws:kms:...").

Multi-Account Migration → may require CMKs in both source and target accounts with cross-account permissions configured manually.

S3 Buckets (create_assessment_s3_bucket, create_logs_s3_bucket)

This module can create two types of S3 buckets used by DMS:

Assessment bucket → stores premigration assessment reports.

Logs bucket → stores DMS task logs if enabled.

When to let the module create S3 buckets (true)

Use in development or test accounts where no existing buckets are dedicated to DMS.

Simplifies setup by automatically creating properly configured S3 buckets with:

Versioning enabled.

CMK encryption by default.

Public access fully blocked.

TLS-only policy enforcement.

Useful for quick testing of premigration assessments and logging.

When to disable bucket creation (false)

Use in production accounts where S3 buckets are centrally managed and naming, policies, or lifecycle rules must conform to organizational standards.

Required if your environment mandates centralized logging buckets or pre-approved assessment storage.

Recommended if your organization already provisions S3 buckets via a separate module or service catalog.

Scenarios

Development/Test Account → enable creation (create_assessment_s3_bucket = true, create_logs_s3_bucket = true if logs are needed).

Production Account → disable creation and supply your own buckets. Use IAM policies and bucket policies that align with compliance requirements.

Multi-Account Migration → assessments may need to be stored in a centralized logging account. In this case, create and manage S3 buckets outside of the module and reference them explicitly.