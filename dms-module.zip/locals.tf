locals {
  merged_tags = merge(
    { Module = "dms-module" },
    var.tags
  )

  kms_arn = var.kms_key_arn != null ? var.kms_key_arn : try(aws_kms_key.this[0].arn, null)

  subnet_group_name = var.replication_subnet_group_name

  source_endpoints  = var.source_endpoints
  target_endpoints  = var.target_endpoints
  replication_tasks = var.replication_tasks
  assessments       = var.premigration_assessments

  assessment_bucket_name = var.create_assessment_s3_bucket ? aws_s3_bucket.assessment[0].id : null
  logs_bucket_name       = var.create_logs_s3_bucket ? aws_s3_bucket.logs[0].id : null
}
