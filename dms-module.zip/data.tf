data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
data "aws_partition" "current" {}

locals {
  account_root_arn = "arn:${data.aws_partition.current.partition}:iam::${data.aws_caller_identity.current.account_id}:root"

  dms_service_principals = [
    "dms.${data.aws_partition.current.dns_suffix}",
    "dms.${data.aws_region.current.name}.${data.aws_partition.current.dns_suffix}"
  ]

  logs_service_principals = [
    "logs.${data.aws_partition.current.dns_suffix}",
    "logs.${data.aws_region.current.name}.${data.aws_partition.current.dns_suffix}"
  ]

  s3_service_principals = [
    "s3.${data.aws_partition.current.dns_suffix}",
    "s3.${data.aws_region.current.name}.${data.aws_partition.current.dns_suffix}"
  ]

  kms_service_principals = [
    "kms.${data.aws_partition.current.dns_suffix}",
    "kms.${data.aws_region.current.name}.${data.aws_partition.current.dns_suffix}"
  ]
}
